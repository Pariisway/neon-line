export function HomePage() {
  return (
    <div className="text-center p-8">
      <h1 className="text-4xl text-yellow-400 mb-4">Welcome to Neon Line!</h1>
      <p className="text-white">Home page content coming soon...</p>
    </div>
  );
}
